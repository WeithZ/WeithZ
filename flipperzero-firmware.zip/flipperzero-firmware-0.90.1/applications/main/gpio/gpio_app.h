#pragma once

#ifdef __cplusplus
extern "C" {
#endif

typedef struct GpioApp GpioApp;

#ifdef __cplusplus
}
#endif
