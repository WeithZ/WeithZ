#pragma once

typedef struct SubGhz SubGhz;
