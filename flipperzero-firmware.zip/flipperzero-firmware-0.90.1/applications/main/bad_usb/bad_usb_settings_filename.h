#pragma once

#define BAD_USB_SETTINGS_FILE_NAME ".badusb.settings"
