#pragma once

#ifdef __cplusplus
extern "C" {
#endif

typedef struct U2fApp U2fApp;

#ifdef __cplusplus
}
#endif
