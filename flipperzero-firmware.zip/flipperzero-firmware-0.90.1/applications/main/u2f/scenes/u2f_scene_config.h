ADD_SCENE(u2f, main, Main)
ADD_SCENE(u2f, error, Error)
