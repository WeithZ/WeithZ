#pragma once

typedef struct iButton iButton;
