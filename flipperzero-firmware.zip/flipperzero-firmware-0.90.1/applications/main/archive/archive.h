#pragma once

typedef struct ArchiveApp ArchiveApp;
