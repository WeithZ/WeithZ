#pragma once

typedef struct Infrared Infrared;
